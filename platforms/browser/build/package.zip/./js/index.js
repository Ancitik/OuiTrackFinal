(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
'use strict';

var ouibus_token = 'W9JdZqSu8EAzM5XSf8fCgw';

var outils = {
    getNomVilleParID: function getNomVilleParID(iden) {
        // On renvoie une promesse qui prend en paramettre une fonction 
        // avec 2 paramètres, le callback de succès et d'erreur
        return new Promise(function (resolve, reject) {
            // Le reste du code ressemble à une méthode AJAX
            $.ajax({
                type: 'GET',
                url: 'https://api.idbus.com/v1/stops',
                dataType: 'json',
                headers: {
                    'Authorization': ouibus_token ? 'Token ' + ouibus_token : null,
                    'Content-Type': 'application/json'
                },
                success: function success(result) {
                    var i;
                    for (i = 0; i < result.stops.length; i++) {
                        if (iden == result.stops[i].id) {
                            resolve(result.stops[i].long_name);
                        }
                    }
                },
                error: function error(xhr, textStatus, errorThrown) {
                    console.log('Error: ' + textStatus + ' ' + errorThrown);
                }
            });
        });
    },

    executeAsyncFunc: async function executeAsyncFunc(d, param) {
        var response = await outils.getNomVilleParID(param);
        d.innerHTML = response;
    }
};

var app = {
    // Application Constructor
    initialize: function initialize() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },

    // deviceready Event Handler
    onDeviceReady: function onDeviceReady() {
        document.getElementById('btnRechercherAvecVilles').addEventListener('click', this.recupererInfoBillet.bind(this), false);

        /*Récupérer les villes dans les selects*/
        var selectVilleDepart = document.getElementById('selectVilleDepart');
        var selectVilleArrivee = document.getElementById('selectVilleArrivee');

        $.ajax({
            type: 'GET',
            url: 'https://api.idbus.com/v1/stops',
            dataType: 'json',
            headers: {
                'Authorization': ouibus_token ? 'Token ' + ouibus_token : null,
                'Content-Type': 'application/json'
            },
            success: function success(result) {
                var i = 0;
                for (i = 0; i < result.stops.length; i++) {
                    var option = document.createElement('option');
                    option.text = result.stops[i].long_name;
                    option.value = result.stops[i].id;
                    selectVilleDepart.add(option);
                }
                for (i = 0; i < result.stops.length; i++) {
                    var option = document.createElement('option');
                    option.text = result.stops[i].long_name;
                    option.value = result.stops[i].id;
                    selectVilleArrivee.add(option);
                }
            },
            error: function error(xhr, textStatus, errorThrown) {
                console.log('Error: ' + textStatus + ' ' + errorThrown);
            }
        });
    },

    recupererInfoBillet: async function recupererInfoBillet() {
        var villeDepart = $('#selectVilleDepart').val();
        var villeArrivee = $('#selectVilleArrivee').val();
        var dateDepart = $('#dateDepart').val();

        if (villeDepart === '' || villeArrivee === '' || dateDepart === '') {
            alert('Remplissez tous les champs !');
            return;
        }

        $.ajax({
            type: 'GET',
            url: 'https://api.idbus.com/v1/fares?origin_id=' + villeDepart + '&destination_id=' + villeArrivee + '&date=' + dateDepart,
            dataType: 'json',
            async: true,
            headers: {
                'Authorization': ouibus_token ? 'Token ' + ouibus_token : null,
                'Content-Type': 'application/json'
            },
            success: function success(result) {
                var i = 0;
                var j = 0;
                if (result.fares.length === 0) {
                    alert('aucuns bilets disponibles pour ce trajet ou cette date'); //TODO : remplacer par un spinner loading
                } else {
                    var i;
                    for (i = 0; i < result.fares.length; i++) {
                        if (result.fares[i].available === true) {
                            var table = document.getElementById('table');
                            var ligne = table.insertRow(i + 1);

                            var num = ligne.insertCell(0);
                            var dep = ligne.insertCell(1);
                            var arr = ligne.insertCell(2);
                            var date = ligne.insertCell(3);

                            dep.innerHTML = result.fares[i].origin_id;
                            num.innerHTML = result.fares[i].legs[0].bus_number;
                            arr.innerHTML = result.fares[i].destination_id;
                            date.innerHTML = result.fares[i].departure; //TODO : convertir en heure

                            outils.executeAsyncFunc(dep, result.fares[i].origin_id);
                            outils.executeAsyncFunc(arr, result.fares[i].destination_id);

                            //TODO : afficher aussi la liste des étapes 
                            //document.getElementById("labelVilleDepart").setAttribute("src","img/img2.jpg");  
                        }
                    }
                    $.mobile.changePage('#page3');
                }
            },
            error: function error(xhr, textStatus, errorThrown) {
                console.log('Error: ' + textStatus + ' ' + errorThrown);
            }
        });
    },

    getMeteoOfCity: function getMeteoOfCity() {
        var city = document.getElementById('txtCity').value;
        var url = 'http://api.openweathermap.org/data/2.5/weather?q=' + city + '&appid=7b2f43782488800965332811d430c186';

        /*Initialisation*/
        var myRequest = new XMLHttpRequest();
        myRequest.open('GET', url, true);

        /*Envoie des données au script*/
        myRequest.send();

        /*Attente de la réponse*/
        myRequest.onreadystatechange = function (aEvt) {
            if (myRequest.readyState == 4) {
                // la requête est terminée
                if (myRequest.status == 200) {
                    // Code HTTP 200 OK
                    var result = JSON.parse(myRequest.responseText);
                    document.getElementById('weather_result').textContent = result.weather[0].description;
                }
            }
        };
    }
};

app.initialize();

},{}]},{},[1])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJzcmNcXGpzXFxpbmRleC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQ0FBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFrQkE7O0FBRUEsSUFBTSxlQUFlLHdCQUFyQjs7QUFFQSxJQUFJLFNBQVM7QUFDTCxzQkFBa0IsMEJBQVMsSUFBVCxFQUFjO0FBQzVCO0FBQ0E7QUFDQSxlQUFPLElBQUksT0FBSixDQUFZLFVBQVUsT0FBVixFQUFtQixNQUFuQixFQUEyQjtBQUMxQztBQUNBLGNBQUUsSUFBRixDQUFPO0FBQ0gsc0JBQU0sS0FESDtBQUVILHFCQUFLLGdDQUZGO0FBR0gsMEJBQVUsTUFIUDtBQUlILHlCQUFTO0FBQ0wscUNBQWlCLDBCQUF3QixZQUF4QixHQUF5QyxJQURyRDtBQUVMLG9DQUFnQjtBQUZYLGlCQUpOO0FBUUgseUJBQVMsaUJBQVUsTUFBVixFQUFrQjtBQUN2Qix3QkFBSSxDQUFKO0FBQ0EseUJBQUssSUFBSSxDQUFULEVBQVksSUFBSSxPQUFPLEtBQVAsQ0FBYSxNQUE3QixFQUFxQyxHQUFyQyxFQUF5QztBQUNyQyw0QkFBSSxRQUFRLE9BQU8sS0FBUCxDQUFhLENBQWIsRUFBZ0IsRUFBNUIsRUFBK0I7QUFDM0Isb0NBQVEsT0FBTyxLQUFQLENBQWEsQ0FBYixFQUFnQixTQUF4QjtBQUNIO0FBQ0o7QUFDSixpQkFmRTtBQWdCSCx1QkFBTyxlQUFVLEdBQVYsRUFBZSxVQUFmLEVBQTJCLFdBQTNCLEVBQXdDO0FBQzNDLDRCQUFRLEdBQVIsQ0FBWSxZQUFZLFVBQVosR0FBeUIsR0FBekIsR0FBK0IsV0FBM0M7QUFDSDtBQWxCRSxhQUFQO0FBb0JELFNBdEJJLENBQVA7QUF1QkgsS0EzQkk7O0FBNkJMLHNCQUFrQixnQ0FBZSxDQUFmLEVBQWtCLEtBQWxCLEVBQXdCO0FBQ3RDLFlBQUksV0FBVyxNQUFNLE9BQU8sZ0JBQVAsQ0FBd0IsS0FBeEIsQ0FBckI7QUFDQSxVQUFFLFNBQUYsR0FBYyxRQUFkO0FBQ0g7QUFoQ0ksQ0FBYjs7QUFtQ0EsSUFBSSxNQUFNO0FBQ047QUFDQSxnQkFBWSxzQkFBWTtBQUNwQixpQkFBUyxnQkFBVCxDQUEwQixhQUExQixFQUF5QyxLQUFLLGFBQUwsQ0FBbUIsSUFBbkIsQ0FBd0IsSUFBeEIsQ0FBekMsRUFBd0UsS0FBeEU7QUFDSCxLQUpLOztBQU1OO0FBQ0EsbUJBQWUseUJBQVc7QUFDdEIsaUJBQVMsY0FBVCxDQUF3Qix5QkFBeEIsRUFBbUQsZ0JBQW5ELENBQW9FLE9BQXBFLEVBQTZFLEtBQUssbUJBQUwsQ0FBeUIsSUFBekIsQ0FBOEIsSUFBOUIsQ0FBN0UsRUFBa0gsS0FBbEg7O0FBRUE7QUFDQSxZQUFJLG9CQUFvQixTQUFTLGNBQVQsQ0FBd0IsbUJBQXhCLENBQXhCO0FBQ0EsWUFBSSxxQkFBcUIsU0FBUyxjQUFULENBQXdCLG9CQUF4QixDQUF6Qjs7QUFFQSxVQUFFLElBQUYsQ0FBTztBQUNILGtCQUFNLEtBREg7QUFFSCxpQkFBSyxnQ0FGRjtBQUdILHNCQUFVLE1BSFA7QUFJSCxxQkFBUztBQUNMLGlDQUFpQiwwQkFBd0IsWUFBeEIsR0FBeUMsSUFEckQ7QUFFTCxnQ0FBZ0I7QUFGWCxhQUpOO0FBUUgscUJBQVMsaUJBQVUsTUFBVixFQUFrQjtBQUN2QixvQkFBSSxJQUFJLENBQVI7QUFDQSxxQkFBSyxJQUFJLENBQVQsRUFBWSxJQUFJLE9BQU8sS0FBUCxDQUFhLE1BQTdCLEVBQXFDLEdBQXJDLEVBQXlDO0FBQ3JDLHdCQUFJLFNBQVMsU0FBUyxhQUFULENBQXVCLFFBQXZCLENBQWI7QUFDQSwyQkFBTyxJQUFQLEdBQWMsT0FBTyxLQUFQLENBQWEsQ0FBYixFQUFnQixTQUE5QjtBQUNBLDJCQUFPLEtBQVAsR0FBZSxPQUFPLEtBQVAsQ0FBYSxDQUFiLEVBQWdCLEVBQS9CO0FBQ0Esc0NBQWtCLEdBQWxCLENBQXNCLE1BQXRCO0FBQ0g7QUFDRCxxQkFBSyxJQUFJLENBQVQsRUFBWSxJQUFJLE9BQU8sS0FBUCxDQUFhLE1BQTdCLEVBQXFDLEdBQXJDLEVBQXlDO0FBQ3JDLHdCQUFJLFNBQVMsU0FBUyxhQUFULENBQXVCLFFBQXZCLENBQWI7QUFDQSwyQkFBTyxJQUFQLEdBQWMsT0FBTyxLQUFQLENBQWEsQ0FBYixFQUFnQixTQUE5QjtBQUNBLDJCQUFPLEtBQVAsR0FBZSxPQUFPLEtBQVAsQ0FBYSxDQUFiLEVBQWdCLEVBQS9CO0FBQ0EsdUNBQW1CLEdBQW5CLENBQXVCLE1BQXZCO0FBQ0g7QUFDSixhQXRCRTtBQXVCSCxtQkFBTyxlQUFVLEdBQVYsRUFBZSxVQUFmLEVBQTJCLFdBQTNCLEVBQXdDO0FBQzNDLHdCQUFRLEdBQVIsQ0FBWSxZQUFZLFVBQVosR0FBeUIsR0FBekIsR0FBK0IsV0FBM0M7QUFDSDtBQXpCRSxTQUFQO0FBMkJILEtBekNLOztBQTJDTix5QkFBcUIscUNBQWtCO0FBQ25DLFlBQUksY0FBYyxFQUFFLG9CQUFGLEVBQXdCLEdBQXhCLEVBQWxCO0FBQ0EsWUFBSSxlQUFlLEVBQUUscUJBQUYsRUFBeUIsR0FBekIsRUFBbkI7QUFDQSxZQUFJLGFBQWEsRUFBRSxhQUFGLEVBQWlCLEdBQWpCLEVBQWpCOztBQUVBLFlBQUssZ0JBQWdCLEVBQWhCLElBQXNCLGlCQUFpQixFQUF2QyxJQUE2QyxlQUFlLEVBQWpFLEVBQW9FO0FBQ2hFLGtCQUFNLDhCQUFOO0FBQ0E7QUFDSDs7QUFFRCxVQUFFLElBQUYsQ0FBTztBQUNILGtCQUFNLEtBREg7QUFFSCxpQkFBSyw4Q0FBNEMsV0FBNUMsR0FBd0Qsa0JBQXhELEdBQTJFLFlBQTNFLEdBQXdGLFFBQXhGLEdBQWlHLFVBRm5HO0FBR0gsc0JBQVUsTUFIUDtBQUlILG1CQUFPLElBSko7QUFLSCxxQkFBUztBQUNMLGlDQUFpQiwwQkFBd0IsWUFBeEIsR0FBeUMsSUFEckQ7QUFFTCxnQ0FBZ0I7QUFGWCxhQUxOO0FBU0gscUJBQVMsaUJBQVUsTUFBVixFQUFrQjtBQUN2QixvQkFBSSxJQUFFLENBQU47QUFDQSxvQkFBSSxJQUFFLENBQU47QUFDQSxvQkFBRyxPQUFPLEtBQVAsQ0FBYSxNQUFiLEtBQXNCLENBQXpCLEVBQTJCO0FBQ3ZCLDBCQUFNLHdEQUFOLEVBRHVCLENBQ3lDO0FBQ25FLGlCQUZELE1BR0s7QUFDRCx3QkFBSSxDQUFKO0FBQ0EseUJBQUssSUFBSSxDQUFULEVBQVksSUFBSSxPQUFPLEtBQVAsQ0FBYSxNQUE3QixFQUFxQyxHQUFyQyxFQUF5QztBQUNyQyw0QkFBSSxPQUFPLEtBQVAsQ0FBYSxDQUFiLEVBQWdCLFNBQWhCLEtBQThCLElBQWxDLEVBQXVDO0FBQ25DLGdDQUFJLFFBQVEsU0FBUyxjQUFULENBQXdCLE9BQXhCLENBQVo7QUFDQSxnQ0FBSSxRQUFRLE1BQU0sU0FBTixDQUFnQixJQUFFLENBQWxCLENBQVo7O0FBRUEsZ0NBQUksTUFBTSxNQUFNLFVBQU4sQ0FBaUIsQ0FBakIsQ0FBVjtBQUNBLGdDQUFJLE1BQU0sTUFBTSxVQUFOLENBQWlCLENBQWpCLENBQVY7QUFDQSxnQ0FBSSxNQUFNLE1BQU0sVUFBTixDQUFpQixDQUFqQixDQUFWO0FBQ0EsZ0NBQUksT0FBTyxNQUFNLFVBQU4sQ0FBaUIsQ0FBakIsQ0FBWDs7QUFFQSxnQ0FBSSxTQUFKLEdBQWdCLE9BQU8sS0FBUCxDQUFhLENBQWIsRUFBZ0IsU0FBaEM7QUFDQSxnQ0FBSSxTQUFKLEdBQWdCLE9BQU8sS0FBUCxDQUFhLENBQWIsRUFBZ0IsSUFBaEIsQ0FBcUIsQ0FBckIsRUFBd0IsVUFBeEM7QUFDQSxnQ0FBSSxTQUFKLEdBQWdCLE9BQU8sS0FBUCxDQUFhLENBQWIsRUFBZ0IsY0FBaEM7QUFDQSxpQ0FBSyxTQUFMLEdBQWlCLE9BQU8sS0FBUCxDQUFhLENBQWIsRUFBZ0IsU0FBakMsQ0FabUMsQ0FZUzs7QUFFNUMsbUNBQU8sZ0JBQVAsQ0FBd0IsR0FBeEIsRUFBNkIsT0FBTyxLQUFQLENBQWEsQ0FBYixFQUFnQixTQUE3QztBQUNBLG1DQUFPLGdCQUFQLENBQXdCLEdBQXhCLEVBQTZCLE9BQU8sS0FBUCxDQUFhLENBQWIsRUFBZ0IsY0FBN0M7O0FBR0E7QUFDQTtBQUNIO0FBQ0o7QUFDRCxzQkFBRSxNQUFGLENBQVMsVUFBVCxDQUFvQixRQUFwQjtBQUNIO0FBRUosYUEzQ0U7QUE0Q0gsbUJBQU8sZUFBVSxHQUFWLEVBQWUsVUFBZixFQUEyQixXQUEzQixFQUF3QztBQUMzQyx3QkFBUSxHQUFSLENBQVksWUFBWSxVQUFaLEdBQXlCLEdBQXpCLEdBQStCLFdBQTNDO0FBQ0g7QUE5Q0UsU0FBUDtBQWdESCxLQXJHSzs7QUF5R04sb0JBQWdCLDBCQUFZO0FBQ3hCLFlBQUksT0FBTyxTQUFTLGNBQVQsQ0FBd0IsU0FBeEIsRUFBbUMsS0FBOUM7QUFDQSxZQUFJLE1BQU0sc0RBQXNELElBQXRELEdBQTZELHlDQUF2RTs7QUFFQTtBQUNBLFlBQUksWUFBWSxJQUFJLGNBQUosRUFBaEI7QUFDQSxrQkFBVSxJQUFWLENBQWUsS0FBZixFQUFzQixHQUF0QixFQUEyQixJQUEzQjs7QUFFQTtBQUNBLGtCQUFVLElBQVY7O0FBRUE7QUFDQSxrQkFBVSxrQkFBVixHQUErQixVQUFVLElBQVYsRUFBZ0I7QUFDM0MsZ0JBQUksVUFBVSxVQUFWLElBQXdCLENBQTVCLEVBQStCO0FBQUU7QUFDN0Isb0JBQUksVUFBVSxNQUFWLElBQW9CLEdBQXhCLEVBQTZCO0FBQUU7QUFDM0Isd0JBQUksU0FBUyxLQUFLLEtBQUwsQ0FBVyxVQUFVLFlBQXJCLENBQWI7QUFDQSw2QkFBUyxjQUFULENBQXdCLGdCQUF4QixFQUEwQyxXQUExQyxHQUF3RCxPQUFPLE9BQVAsQ0FBZSxDQUFmLEVBQWtCLFdBQTFFO0FBQ0g7QUFDSjtBQUNKLFNBUEQ7QUFRSDtBQTdISyxDQUFWOztBQWdJQSxJQUFJLFVBQUoiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dmFyIGY9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKTt0aHJvdyBmLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsZn12YXIgbD1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwobC5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxsLGwuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiLypcclxuICogTGljZW5zZWQgdG8gdGhlIEFwYWNoZSBTb2Z0d2FyZSBGb3VuZGF0aW9uIChBU0YpIHVuZGVyIG9uZVxyXG4gKiBvciBtb3JlIGNvbnRyaWJ1dG9yIGxpY2Vuc2UgYWdyZWVtZW50cy4gIFNlZSB0aGUgTk9USUNFIGZpbGVcclxuICogZGlzdHJpYnV0ZWQgd2l0aCB0aGlzIHdvcmsgZm9yIGFkZGl0aW9uYWwgaW5mb3JtYXRpb25cclxuICogcmVnYXJkaW5nIGNvcHlyaWdodCBvd25lcnNoaXAuICBUaGUgQVNGIGxpY2Vuc2VzIHRoaXMgZmlsZVxyXG4gKiB0byB5b3UgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlXHJcbiAqIFwiTGljZW5zZVwiKTsgeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZVxyXG4gKiB3aXRoIHRoZSBMaWNlbnNlLiAgWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XHJcbiAqXHJcbiAqIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxyXG4gKlxyXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsXHJcbiAqIHNvZnR3YXJlIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuXHJcbiAqIFwiQVMgSVNcIiBCQVNJUywgV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZXHJcbiAqIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuICBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZVxyXG4gKiBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kIGxpbWl0YXRpb25zXHJcbiAqIHVuZGVyIHRoZSBMaWNlbnNlLlxyXG4gKi9cclxuJ3VzZSBzdHJpY3QnO1xyXG5cclxuY29uc3Qgb3VpYnVzX3Rva2VuID0gJ1c5SmRacVN1OEVBek01WFNmOGZDZ3cnO1xyXG5cclxudmFyIG91dGlscyA9IHtcclxuICAgICAgICBnZXROb21WaWxsZVBhcklEOiBmdW5jdGlvbihpZGVuKXtcclxuICAgICAgICAgICAgLy8gT24gcmVudm9pZSB1bmUgcHJvbWVzc2UgcXVpIHByZW5kIGVuIHBhcmFtZXR0cmUgdW5lIGZvbmN0aW9uIFxyXG4gICAgICAgICAgICAvLyBhdmVjIDIgcGFyYW3DqHRyZXMsIGxlIGNhbGxiYWNrIGRlIHN1Y2PDqHMgZXQgZCdlcnJldXJcclxuICAgICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICAgICAgICAgIC8vIExlIHJlc3RlIGR1IGNvZGUgcmVzc2VtYmxlIMOgIHVuZSBtw6l0aG9kZSBBSkFYXHJcbiAgICAgICAgICAgICAgICAkLmFqYXgoe1xyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICdHRVQnLFxyXG4gICAgICAgICAgICAgICAgICAgIHVybDogJ2h0dHBzOi8vYXBpLmlkYnVzLmNvbS92MS9zdG9wcycsXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YVR5cGU6ICdqc29uJyxcclxuICAgICAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogb3VpYnVzX3Rva2VuID8gYFRva2VuICR7b3VpYnVzX3Rva2VufWAgOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBzdWNjZXNzOiBmdW5jdGlvbiAocmVzdWx0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGkgPSAwOyBpIDwgcmVzdWx0LnN0b3BzLmxlbmd0aDsgaSsrKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpZGVuID09IHJlc3VsdC5zdG9wc1tpXS5pZCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXN1bHQuc3RvcHNbaV0ubG9uZ19uYW1lKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgZXJyb3I6IGZ1bmN0aW9uICh4aHIsIHRleHRTdGF0dXMsIGVycm9yVGhyb3duKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdFcnJvcjogJyArIHRleHRTdGF0dXMgKyAnICcgKyBlcnJvclRocm93bik7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBcclxuICAgICAgICBleGVjdXRlQXN5bmNGdW5jOiBhc3luYyBmdW5jdGlvbihkLCBwYXJhbSl7XHJcbiAgICAgICAgICAgIHZhciByZXNwb25zZSA9IGF3YWl0IG91dGlscy5nZXROb21WaWxsZVBhcklEKHBhcmFtKTtcclxuICAgICAgICAgICAgZC5pbm5lckhUTUwgPSByZXNwb25zZTtcclxuICAgICAgICB9XHJcbn07XHJcblxyXG52YXIgYXBwID0ge1xyXG4gICAgLy8gQXBwbGljYXRpb24gQ29uc3RydWN0b3JcclxuICAgIGluaXRpYWxpemU6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdkZXZpY2VyZWFkeScsIHRoaXMub25EZXZpY2VSZWFkeS5iaW5kKHRoaXMpLCBmYWxzZSk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIGRldmljZXJlYWR5IEV2ZW50IEhhbmRsZXJcclxuICAgIG9uRGV2aWNlUmVhZHk6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdidG5SZWNoZXJjaGVyQXZlY1ZpbGxlcycpLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdGhpcy5yZWN1cGVyZXJJbmZvQmlsbGV0LmJpbmQodGhpcyksIGZhbHNlKTtcclxuXHJcbiAgICAgICAgLypSw6ljdXDDqXJlciBsZXMgdmlsbGVzIGRhbnMgbGVzIHNlbGVjdHMqL1xyXG4gICAgICAgIHZhciBzZWxlY3RWaWxsZURlcGFydCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzZWxlY3RWaWxsZURlcGFydCcpO1xyXG4gICAgICAgIHZhciBzZWxlY3RWaWxsZUFycml2ZWUgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc2VsZWN0VmlsbGVBcnJpdmVlJyk7XHJcblxyXG4gICAgICAgICQuYWpheCh7XHJcbiAgICAgICAgICAgIHR5cGU6ICdHRVQnLFxyXG4gICAgICAgICAgICB1cmw6ICdodHRwczovL2FwaS5pZGJ1cy5jb20vdjEvc3RvcHMnLFxyXG4gICAgICAgICAgICBkYXRhVHlwZTogJ2pzb24nLFxyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6IG91aWJ1c190b2tlbiA/IGBUb2tlbiAke291aWJ1c190b2tlbn1gIDogbnVsbCxcclxuICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbidcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc3VjY2VzczogZnVuY3Rpb24gKHJlc3VsdCkge1xyXG4gICAgICAgICAgICAgICAgdmFyIGkgPSAwO1xyXG4gICAgICAgICAgICAgICAgZm9yIChpID0gMDsgaSA8IHJlc3VsdC5zdG9wcy5sZW5ndGg7IGkrKyl7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIG9wdGlvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ29wdGlvbicpO1xyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbi50ZXh0ID0gcmVzdWx0LnN0b3BzW2ldLmxvbmdfbmFtZTtcclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24udmFsdWUgPSByZXN1bHQuc3RvcHNbaV0uaWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZWN0VmlsbGVEZXBhcnQuYWRkKG9wdGlvbik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBmb3IgKGkgPSAwOyBpIDwgcmVzdWx0LnN0b3BzLmxlbmd0aDsgaSsrKXtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgb3B0aW9uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnb3B0aW9uJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLnRleHQgPSByZXN1bHQuc3RvcHNbaV0ubG9uZ19uYW1lO1xyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbi52YWx1ZSA9IHJlc3VsdC5zdG9wc1tpXS5pZDtcclxuICAgICAgICAgICAgICAgICAgICBzZWxlY3RWaWxsZUFycml2ZWUuYWRkKG9wdGlvbik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGVycm9yOiBmdW5jdGlvbiAoeGhyLCB0ZXh0U3RhdHVzLCBlcnJvclRocm93bikge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ0Vycm9yOiAnICsgdGV4dFN0YXR1cyArICcgJyArIGVycm9yVGhyb3duKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfSxcclxuXHJcbiAgICByZWN1cGVyZXJJbmZvQmlsbGV0OiBhc3luYyBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIHZpbGxlRGVwYXJ0ID0gJCgnI3NlbGVjdFZpbGxlRGVwYXJ0JykudmFsKCk7XHJcbiAgICAgICAgdmFyIHZpbGxlQXJyaXZlZSA9ICQoJyNzZWxlY3RWaWxsZUFycml2ZWUnKS52YWwoKTtcclxuICAgICAgICB2YXIgZGF0ZURlcGFydCA9ICQoJyNkYXRlRGVwYXJ0JykudmFsKCk7XHJcblxyXG4gICAgICAgIGlmICggdmlsbGVEZXBhcnQgPT09ICcnIHx8IHZpbGxlQXJyaXZlZSA9PT0gJycgfHwgZGF0ZURlcGFydCA9PT0gJycpe1xyXG4gICAgICAgICAgICBhbGVydCgnUmVtcGxpc3NleiB0b3VzIGxlcyBjaGFtcHMgIScpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAkLmFqYXgoe1xyXG4gICAgICAgICAgICB0eXBlOiAnR0VUJyxcclxuICAgICAgICAgICAgdXJsOiAnaHR0cHM6Ly9hcGkuaWRidXMuY29tL3YxL2ZhcmVzP29yaWdpbl9pZD0nK3ZpbGxlRGVwYXJ0KycmZGVzdGluYXRpb25faWQ9Jyt2aWxsZUFycml2ZWUrJyZkYXRlPScrZGF0ZURlcGFydCxcclxuICAgICAgICAgICAgZGF0YVR5cGU6ICdqc29uJyxcclxuICAgICAgICAgICAgYXN5bmM6IHRydWUsXHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogb3VpYnVzX3Rva2VuID8gYFRva2VuICR7b3VpYnVzX3Rva2VufWAgOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzdWNjZXNzOiBmdW5jdGlvbiAocmVzdWx0KSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgaT0wO1xyXG4gICAgICAgICAgICAgICAgdmFyIGo9MDtcclxuICAgICAgICAgICAgICAgIGlmKHJlc3VsdC5mYXJlcy5sZW5ndGg9PT0wKXtcclxuICAgICAgICAgICAgICAgICAgICBhbGVydCgnYXVjdW5zIGJpbGV0cyBkaXNwb25pYmxlcyBwb3VyIGNlIHRyYWpldCBvdSBjZXR0ZSBkYXRlJyk7Ly9UT0RPIDogcmVtcGxhY2VyIHBhciB1biBzcGlubmVyIGxvYWRpbmdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBpO1xyXG4gICAgICAgICAgICAgICAgICAgIGZvciAoaSA9IDA7IGkgPCByZXN1bHQuZmFyZXMubGVuZ3RoOyBpKyspe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0LmZhcmVzW2ldLmF2YWlsYWJsZSA9PT0gdHJ1ZSl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgdGFibGUgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndGFibGUnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBsaWduZSA9IHRhYmxlLmluc2VydFJvdyhpKzEpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBudW0gPSBsaWduZS5pbnNlcnRDZWxsKDApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGRlcCA9IGxpZ25lLmluc2VydENlbGwoMSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgYXJyID0gbGlnbmUuaW5zZXJ0Q2VsbCgyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBkYXRlID0gbGlnbmUuaW5zZXJ0Q2VsbCgzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVwLmlubmVySFRNTCA9IHJlc3VsdC5mYXJlc1tpXS5vcmlnaW5faWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW0uaW5uZXJIVE1MID0gcmVzdWx0LmZhcmVzW2ldLmxlZ3NbMF0uYnVzX251bWJlcjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyci5pbm5lckhUTUwgPSByZXN1bHQuZmFyZXNbaV0uZGVzdGluYXRpb25faWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRlLmlubmVySFRNTCA9IHJlc3VsdC5mYXJlc1tpXS5kZXBhcnR1cmU7IC8vVE9ETyA6IGNvbnZlcnRpciBlbiBoZXVyZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3V0aWxzLmV4ZWN1dGVBc3luY0Z1bmMoZGVwLCByZXN1bHQuZmFyZXNbaV0ub3JpZ2luX2lkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG91dGlscy5leGVjdXRlQXN5bmNGdW5jKGFyciwgcmVzdWx0LmZhcmVzW2ldLmRlc3RpbmF0aW9uX2lkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vVE9ETyA6IGFmZmljaGVyIGF1c3NpIGxhIGxpc3RlIGRlcyDDqXRhcGVzIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9kb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImxhYmVsVmlsbGVEZXBhcnRcIikuc2V0QXR0cmlidXRlKFwic3JjXCIsXCJpbWcvaW1nMi5qcGdcIik7ICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAkLm1vYmlsZS5jaGFuZ2VQYWdlKCcjcGFnZTMnKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBlcnJvcjogZnVuY3Rpb24gKHhociwgdGV4dFN0YXR1cywgZXJyb3JUaHJvd24pIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdFcnJvcjogJyArIHRleHRTdGF0dXMgKyAnICcgKyBlcnJvclRocm93bik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0sXHJcblxyXG5cclxuXHJcbiAgICBnZXRNZXRlb09mQ2l0eTogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBjaXR5ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3R4dENpdHknKS52YWx1ZTtcclxuICAgICAgICB2YXIgdXJsID0gJ2h0dHA6Ly9hcGkub3BlbndlYXRoZXJtYXAub3JnL2RhdGEvMi41L3dlYXRoZXI/cT0nICsgY2l0eSArICcmYXBwaWQ9N2IyZjQzNzgyNDg4ODAwOTY1MzMyODExZDQzMGMxODYnO1xyXG5cclxuICAgICAgICAvKkluaXRpYWxpc2F0aW9uKi9cclxuICAgICAgICB2YXIgbXlSZXF1ZXN0ID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XHJcbiAgICAgICAgbXlSZXF1ZXN0Lm9wZW4oJ0dFVCcsIHVybCwgdHJ1ZSk7XHJcblxyXG4gICAgICAgIC8qRW52b2llIGRlcyBkb25uw6llcyBhdSBzY3JpcHQqL1xyXG4gICAgICAgIG15UmVxdWVzdC5zZW5kKCk7XHJcblxyXG4gICAgICAgIC8qQXR0ZW50ZSBkZSBsYSByw6lwb25zZSovXHJcbiAgICAgICAgbXlSZXF1ZXN0Lm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uIChhRXZ0KSB7XHJcbiAgICAgICAgICAgIGlmIChteVJlcXVlc3QucmVhZHlTdGF0ZSA9PSA0KSB7IC8vIGxhIHJlcXXDqnRlIGVzdCB0ZXJtaW7DqWVcclxuICAgICAgICAgICAgICAgIGlmIChteVJlcXVlc3Quc3RhdHVzID09IDIwMCkgeyAvLyBDb2RlIEhUVFAgMjAwIE9LXHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdCA9IEpTT04ucGFyc2UobXlSZXF1ZXN0LnJlc3BvbnNlVGV4dCk7XHJcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3dlYXRoZXJfcmVzdWx0JykudGV4dENvbnRlbnQgPSByZXN1bHQud2VhdGhlclswXS5kZXNjcmlwdGlvbjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbn07XHJcblxyXG5hcHAuaW5pdGlhbGl6ZSgpO1xyXG4iXX0=
